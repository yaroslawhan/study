function y=F1(x)
    y = x.^3 - 12.*x - 10;
end