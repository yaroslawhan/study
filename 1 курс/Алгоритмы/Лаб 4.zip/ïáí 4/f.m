function y = f(x)
    y = (log(x))./(x.*(log(x)).^(1/2));
end