function y=F2(x)
    y=(1+(0.8).*x.^2)./(1.5+sqrt((0.4).*x.^2+1));
end